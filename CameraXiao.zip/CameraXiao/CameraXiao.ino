#include <Arduino.h>
#include "esp_camera.h"
#include <WiFi.h>
#include "board_config.h" // Preserves your specific board configurations

// Include the Micro-RTSP component headers
#include <MicroRTSP.h>

// ===========================
// Enter your WiFi credentials
// ===========================
const char *ssid = "ASTI-Interns";
const char *password = "DOST-ASTI-INTERNS-2026";

// Define the streaming port and network server instances
#define RTSP_PORT 8554
WiFiServer rtspServer(RTSP_PORT);
RTSPServer rtsp(&rtspServer);

void setupLedFlash();

void setup() {
  Serial.begin(115200);
  Serial.setDebugOutput(true);
  Serial.println();

  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  
  // Set configuration parameters optimized for RTSP framing streaming
  config.frame_size = FRAMESIZE_VGA;     // 640x480 resolution
  config.pixel_format = PIXFORMAT_JPEG; 
  config.grab_mode = CAMERA_GRAB_LATEST; // Forces the hardware to always give us the newest frame
  config.fb_location = CAMERA_FB_IN_PSRAM;
  config.jpeg_quality = 12;
  config.fb_count = 2;

  // Camera initialization sequence
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x", err);
    return;
  }

  sensor_t *s = esp_camera_sensor_get();
  // Reverse default vertical flips if present on specific sensor lines
  if (s->id.PID == OV3660_PID) {
    s->set_vflip(s, 1);       
    s->set_brightness(s, 1);   
    s->set_saturation(s, -2);  
  }

#if defined(CAMERA_MODEL_M5STACK_WIDE) || defined(CAMERA_MODEL_M5STACK_ESP32CAM)
  s->set_vflip(s, 1);
  s->set_hmirror(s, 1);
#endif

#if defined(CAMERA_MODEL_ESP32S3_EYE)
  s->set_vflip(s, 1);
#endif

// Setup LED Flash if pin definitions match board_config
#if defined(LED_GPIO_NUM)
  setupLedFlash();
#endif

  // Establish stable network link
  WiFi.begin(ssid, password);
  WiFi.setSleep(false); // CRITICAL: Prevents the ESP32 radio from sleeping, dropping latency by ~100ms

  Serial.print("WiFi connecting");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");

  // Start listening for RTSP network requests on port 8554
  rtspServer.begin();

  Serial.print("Camera Ready! Use your Python App to connect to: 'rtsp://");
  Serial.print(WiFi.localIP());
  Serial.printf(":%d/mjpeg/1'\n", RTSP_PORT);
}

void loop() {
  // 1. Monitor incoming TCP connection handshakes from OpenCV
  WiFiClient client = rtspServer.accept();
  if (client) {
    rtsp.addClient(client);
  }

  // 2. If an active streaming session exists, cycle frames
  if (rtsp.hasClients()) {
    camera_fb_t *fb = esp_camera_fb_get();
    if (fb) {
      // Direct raw buffer injection across the RTSP connection
      rtsp.writeFrame(fb->buf, fb->len);
      esp_camera_fb_return(fb); // Immediately free memory back to DMA/PSRAM arrays
    }
  }

  // 3. Let the streaming core maintain keep-alive packets and internal stack states
  rtsp.update();
}